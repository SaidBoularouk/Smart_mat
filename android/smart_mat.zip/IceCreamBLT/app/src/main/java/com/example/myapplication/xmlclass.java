package com.example.myapplication;

import android.content.Context;
import android.util.Xml;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmlpull.v1.XmlSerializer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

public class xmlclass {


    public  xmlclass(Context context){
        this.context = context;
    }
    XmlSerializer xmlSerializer = Xml.newSerializer();

    Prayer p(){
      Prayer prayer  = new Prayer();
      prayer.setTitle("title1");
      prayer.setTodayDate("date1");
      prayer.setRunningTime("23,56");
      prayer.setNbrRaqa("2");
      prayer.setNbrSajda("4");
      return prayer;
    }


    String ns=null;
    File directoryToStore;
    List<Integer> sajdas = null;

    String prayer = "prayer";
    String name = "Fajr";
    String runningTime = "runningTime";
    String todayDate = "date";
    String prayerDate = "prayerdate";
    String nbrRaqa = "nbrRaqa";
    String rootName = "prayers_xml";
    String nbrSajda = "nbrSajda";
    String date = "date";
    String key = "key";
    String value = "value";
    String pathToroot = "//prayers_xml/date[@value]";
    Context context;


    public File getF() {
        directoryToStore = context.getExternalFilesDir("smartcarpet");
        return new File(directoryToStore, "salat.xml");
    }

    public void setF(File f) {
        this.f = f;
    }

    File f;


    public  void createFile() {

        directoryToStore = context.getExternalFilesDir("smartcarpet");
        if (!directoryToStore.exists()) {
            if (directoryToStore.mkdir()) ; //directory is created;
        }
        f = new File(directoryToStore, "salat.xml");
        if (!f.exists()) {
            try {
                f.createNewFile();
                writeXml();

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
        }

    }

     public void writeXml() {

        try {
            FileOutputStream file = new FileOutputStream(getF());

            StringWriter writer = new StringWriter();
            xmlSerializer.setOutput(writer);
            xmlSerializer.startDocument("UTF-8", true);
            xmlSerializer.startTag(ns, rootName);

      //      insertPrayers(prayers);

            xmlSerializer.endTag(ns, rootName);
            xmlSerializer.endDocument();
            xmlSerializer.flush();
            String dataWrite = writer.toString();
            file.write(dataWrite.getBytes());
            file.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();

        } catch (IllegalArgumentException e) {
            e.printStackTrace();

        } catch (IllegalStateException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    public void add( Prayer objectPrayer){
        String newdate = objectPrayer.getToayDate();
        String newprayer = objectPrayer.getTitle();
        String newDateprayer = objectPrayer.getPrayerDate();
        String newraqa = objectPrayer.getNbrRaqa()+"";
        String newsajda = objectPrayer.getNbrSajda()+"";
        String newRunning = objectPrayer.getRunningTime();
        Document doc = null;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            doc = db.parse(getF());

            Node _root =  doc.getFirstChild();
            Element _newdate = null;
            // Get the document's root XML node

            Element _newprayer =  null;

            if (NodExist(date, newdate)== -1) {
                _newdate = doc.createElement(date);
                _newdate.setAttribute(value, newdate);
            }else{
                int i=NodExist(date, newdate);
                _newdate = (Element) _root.getChildNodes().item(i);
            }
            if (NodExist(date+"/"+prayer, newprayer)== -1) {
                _newprayer =  doc.createElement(prayer);
                _newprayer.setAttribute(value, newprayer);
            }else{
                _newdate.removeChild(getNode(prayer, _newdate.getChildNodes() ));
                _newdate.removeChild(getNode(prayerDate, _newdate.getChildNodes() ));
                _newdate.removeChild(getNode(nbrRaqa, _newdate.getChildNodes() ));
                _newdate.removeChild(getNode(nbrSajda, _newdate.getChildNodes() ));
                _newdate.removeChild(getNode(runningTime, _newdate.getChildNodes() ));
            }
            _newprayer = doc.createElement(prayer);
            _newprayer.setAttribute(value, newprayer);

            Element _newDateprayer = doc.createElement(prayerDate);
            _newDateprayer.setAttribute(value, newDateprayer);

            Element _newraqa = doc.createElement(nbrRaqa);
            _newraqa.setAttribute(value, newraqa);

            Element _newsajda = doc.createElement(nbrSajda);
            _newsajda.setAttribute(value, newsajda);

            Element _newrunning = doc.createElement(runningTime);
            _newrunning.setAttribute(value, newRunning);

            _newprayer.appendChild(_newDateprayer);
            _newprayer.appendChild(_newraqa);
            _newprayer.appendChild(_newsajda);
            _newprayer.appendChild(_newrunning);

            _newdate.appendChild(_newprayer);

            if (NodExist(date, newdate)== -1) {
                _root.appendChild(_newdate);
            }

            DOMSource source = new DOMSource(doc);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            StreamResult result = new StreamResult(getF());
            transformer.transform(source, result);

        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }


    protected int NodExist(String keyNode, String newdate){
        Document doc = null;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        int exist=-1;  Node _node = null;
        // Create XPathFactory object
        XPathFactory xpathFactory = XPathFactory.newInstance();
        // Create XPath object
        XPath xpath = xpathFactory.newXPath();
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            doc = db.parse(getF());
            Node _root =  doc.getFirstChild();
            // Create XPathExpression object
            XPathExpression expr = xpath.compile("//"+rootName+"/"+ keyNode + "[@value]" );
            // Evaluate expression result on XML document
            NodeList nodeList = (NodeList) expr.evaluate(_root, XPathConstants.NODESET);

            if(nodeList != null  && nodeList.getLength() > 0) {
                for (int i = 0; i < nodeList.getLength(); i++) {
                    Node node = nodeList.item(i);
                    String key = node.getAttributes().getNamedItem(value).getNodeValue();
                  //  System.out.println(key);
                    if (key.equalsIgnoreCase(newdate)) {
                 //       System.out.println("node: " + key + ", "+ node + " , " + i );
                        exist = i;
                    }
                }
            }

        }
        catch ( Exception e ) {
            e.printStackTrace();
        }

        return exist;
    }

    public ArrayList<ArrayList<Prayer>> getnodes(String mydate){
        Document doc = null;
        ArrayList<ArrayList<Prayer>> array=new ArrayList<ArrayList<Prayer>>();
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
            doc = db.parse(getF());
            NodeList root = doc.getChildNodes();

            Node _root = getNode(rootName, root);

            if (mydate == null) {
                NodeList nodelist = _root.getChildNodes();
                if (nodelist.getLength() > 0) {
                    for (int i = 0; i < nodelist.getLength(); i++) {
                        Node mynode = nodelist.item(i);
                        List<Prayer> pr = getPrayersDate(mynode);
                        array.add((ArrayList<Prayer>) pr);
                     }
                }
            } else {
                if (NodExist(date, mydate) != -1) {
                    int i = NodExist(date, mydate);
                    Node mynode = _root.getChildNodes().item(i);
                    List<Prayer> pr = getPrayersDate(mynode);
                    array.add((ArrayList<Prayer>) pr);
                }
            }
            return array;
        }
        catch ( Exception e ) {
           e.printStackTrace();
            return null;
        }

    }


    protected  ArrayList<Prayer> getPrayersDate(Node datePrayers){
        ArrayList<Prayer> ListPrayers = new ArrayList<Prayer>();
        NodeList nodelist = datePrayers.getChildNodes();

        for(int i=0; i< nodelist.getLength(); i++ ) {
            Node nodePrayers = datePrayers.getChildNodes().item(i);
            ListPrayers.add(getPrayerDetail(datePrayers, nodePrayers));
        }
        return ListPrayers;
    }

    protected Prayer getPrayerDetail(Node todayDate, Node pr ) {
        Prayer objectPrayer = new Prayer();
        objectPrayer.setTodayDate(todayDate.getAttributes().getNamedItem(value).getNodeValue());

        NodeList nodelist = todayDate.getChildNodes();
       // Node pr = getNode(prayer, nodelist);
        objectPrayer.setTitle(pr.getAttributes().getNamedItem(value).getNodeValue());

        NodeList prayerNodes = pr.getChildNodes();
        for (int x = 0; x < prayerNodes.getLength(); x++) {
            objectPrayer.setNbrSajda(getNode(nbrSajda, prayerNodes).
                    getAttributes().getNamedItem(value).getNodeValue());
            objectPrayer.setNbrRaqa(getNode(nbrRaqa, prayerNodes).
                    getAttributes().getNamedItem(value).getNodeValue());
            objectPrayer.setRunningTime(getNode(runningTime, prayerNodes).
                    getAttributes().getNamedItem(value).getNodeValue());
            objectPrayer.setPrayerDate(getNode(prayerDate, prayerNodes).
                    getAttributes().getNamedItem(value).getNodeValue());
        }
       return  objectPrayer;

    }

    protected String getNodeValue( Node node ) {
        NodeList childNodes = node.getChildNodes();
        for (int x = 0; x < childNodes.getLength(); x++ ) {
            Node data = childNodes.item(x);
            if ( data.getNodeType() == Node.TEXT_NODE )
                return data.getNodeValue();
        }
        return "";
    }


    protected Node getNode(String tagName, NodeList nodes) {
        for ( int x = 0; x < nodes.getLength(); x++ ) {
            Node node = nodes.item(x);
            if (node.getNodeName().equalsIgnoreCase(tagName)) {
                return node;
            }
        }
        return null;
    }


    protected String getNodeValue(String tagName, NodeList nodes ) {
        for ( int x = 0; x < nodes.getLength(); x++ ) {
            Node node = nodes.item(x);
            if (node.getNodeName().equalsIgnoreCase(tagName)) {
                NodeList childNodes = node.getChildNodes();
                for (int y = 0; y < childNodes.getLength(); y++ ) {
                    Node data = childNodes.item(y);
                    if ( data.getNodeType() == Node.TEXT_NODE )
                        return data.getNodeValue();
                }
            }
        }
        return "";
    }

    protected String getNodeAttr(String attrName, Node node ) {
        NamedNodeMap attrs = node.getAttributes();
        for (int y = 0; y < attrs.getLength(); y++ ) {
            Node attr = attrs.item(y);
            if (attr.getNodeName().equalsIgnoreCase(attrName)) {
                return attr.getNodeValue();
            }
        }
        return "";
    }

    protected String getNodeAttr(String tagName, String attrName, NodeList nodes ) {
        for ( int x = 0; x < nodes.getLength(); x++ ) {
            Node node = nodes.item(x);
            if (node.getNodeName().equalsIgnoreCase(tagName)) {
                NodeList childNodes = node.getChildNodes();
                for (int y = 0; y < childNodes.getLength(); y++ ) {
                    Node data = childNodes.item(y);
                    if ( data.getNodeType() == Node.ATTRIBUTE_NODE ) {
                        if ( data.getNodeName().equalsIgnoreCase(attrName) )
                            return data.getNodeValue();
                    }
                }
            }
        }

        return "";
    }


    private static String getXPath(Node node) {
        Node parent = node.getParentNode();
        if (parent == null) {
            return node.getNodeName();
        }
        return getXPath(parent) + "/" + node.getNodeName();
    }

//    protected void setNodeValue(String tagName, String value, NodeList nodes) {
//        Node node = getNode(tagName, nodes);
//        if ( node == null )
//            return;
//
//        // Locate the child text node and change its value
//        NodeList childNodes = node.getChildNodes();
//        for (int y = 0; y < childNodes.getLength(); y++ ) {
//            Node data = childNodes.item(y);
//            if ( data.getNodeType() == Node.TEXT_NODE ) {
//                data.setNodeValue(value);
//                return;
//            }
//        }
//    }
//
//    protected void addNode(String tagName, String value, Node parent) {
//        Document dom = parent.getOwnerDocument();
//        // Create a new Node with the given tag name
//        Node node = dom.createElement(tagName);
//        // Add the node value as a child text node
//        Text nodeVal = dom.createTextNode(value);
//        Node c = node.appendChild(nodeVal);
//        // Add the new node structure to the parent node
//        parent.appendChild(c);
//    }
//
//
//
//

//    public void insertPrayers(Prayer prayerObject) throws IOException {
//
//        xmlSerializer.startTag(ns, todayDate);
//        xmlSerializer.attribute(ns, value, prayerObject.getToayDate()+"");
//        xmlSerializer.startTag(ns, prayer);
//        xmlSerializer.attribute(ns, value, prayerObject.getTitle());
//
//        xmlSerializer.startTag(ns, prayerDate);
//        xmlSerializer.attribute(ns, value, ""+prayerObject.getPrayerDate());
//        xmlSerializer.endTag(ns, prayerDate);
//
//        xmlSerializer.startTag(ns, nbrRaqa);
//        xmlSerializer.attribute(ns, value, prayerObject.getNbrRaqa()+"");
//        xmlSerializer.endTag(ns, nbrRaqa);
//
//        insertSajda(sajdas);
//
//        xmlSerializer.endTag(null, prayer);
//        xmlSerializer.endTag(ns, todayDate);
//    }
//
//
//    public void insertSajda (List<Integer> sajdas) throws IOException {
//        String runningTime="";
//        if(sajdas != null) {
//            for (int i = 0; i < sajdas.size(); i++) {
//                runningTime = sajdas.get(i) + ",";
//
//            }
//            runningTime.substring(runningTime.length()-1);
//            xmlSerializer.startTag(null, nbrSajda );
//            xmlSerializer.attribute(ns, nbrSajda, runningTime);
//            xmlSerializer.endTag(null, nbrSajda );
//        }
//
//    }


}
