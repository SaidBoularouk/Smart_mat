package com.example.myapplication;

import android.annotation.TargetApi;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@TargetApi(21)
public class esp32class {

    private Handler mHandler;
    private static final long SCAN_PERIOD = 10000;
    private BluetoothLeScanner mLEScanner;
    private ScanSettings settings;
    private List<ScanFilter> filters;
    private BluetoothGatt mBluetoothGatt;

    private Context context;

    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;


    public final static String ACTION_GATT_CONNECTING =
            "com.example.bluetooth.le.ACTION_GATT_CONNECTING";
    public final static String ACTION_GATT_CONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "com.example.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "com.example.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =
            "com.example.bluetooth.le.EXTRA_DATA";

    private int connectionState = STATE_DISCONNECTED;



    private static String CHAR1 = "00001801-0000-1000-8000-00805f9b34fb";
    private static String CHAR2 = "00001800-0000-1000-8000-00805f9b34fb";
    public static final UUID UUID_CHAR1 = UUID.fromString(CHAR1);
    public static final UUID UUID_CHAR2 = UUID.fromString(CHAR2);


    private static String DESCRIPTOR = "00002902-0000-1000-8000-00805f9b34fb";
    public static final UUID UUID_DESCRIPTOR = UUID.fromString(DESCRIPTOR);


    private static String UART_SERVICE = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
    private static String RX_CHAR = "6e400002-b5a3-f393-e0a9-e50e24dcca9e";
    private static String TX_CHAR = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";
    public static final UUID UART_SERVICE_UUID = UUID.fromString(UART_SERVICE);
    public static final UUID RX_CHAR_UUID = UUID.fromString(RX_CHAR);
    public static final UUID TX_CHAR_UUID = UUID.fromString(TX_CHAR);

    private static ArrayAdapter<String> adapter = null;
    private static ArrayList<String> listItems=new ArrayList<String>();

    private BluetoothGattCharacteristic CharRX=null;
    private BluetoothGattCharacteristic CharTX=null;
    BluetoothGattDescriptor descriptor =null;
    BluetoothGattService mBluetoothGattService=null;
    BluetoothManager mBluetoothManager;
    private BluetoothAdapter  mBluetoothAdapter;
    private  BluetoothDevice btDevice;

    public void setDevice(BluetoothDevice device) {
        this.device = device;
    }

    public BluetoothDevice getDevice() {
        return device;
    }

    private BluetoothDevice device = null;


    public final static String DEVICE_DOES_NOT_SUPPORT_UART =
            "com.nordicsemi.nrfUART.DEVICE_DOES_NOT_SUPPORT_UART";


    public esp32class(Context context, Handler mhandler){
        this.context = context;
        this.mHandler = mhandler;
        this.mBluetoothAdapter = PhoneBltClass.mBluetoothManager.getAdapter();
        this.mBluetoothManager = PhoneBltClass.mBluetoothManager;
        this.device = PhoneBltClass.mydevice;
    }

    //METHOD WHICH WILL HANDLE DYNAMIC INSERTION
    public void addItems(final String d, final String s) {
        ((Activity)context).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String l = d +": " + s;
                if(!listItems.contains(l)) {
                    listItems.add(l);
                }
                adapter.notifyDataSetChanged();
            }
        });
    }

    public void displayToast(String str) {
        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
    }


    public void connect(final BluetoothDevice device) {
        if (mBluetoothGatt == null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    //  setPin(device, PIN);
                    connectionState = STATE_CONNECTING;
                    setconnectionState(STATE_CONNECTING);
                    mBluetoothGatt = device.connectGatt(context, false, mBluetoothGattCallback);
                    scanLeDevice(false);
                }
            });
        }
    }


    public void disconnect() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            displayToast ("BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.disconnect();
        mBluetoothGatt.close();
    }

    public boolean initialize() {
        // For API level 18 and above, get a reference to BluetoothAdapter through
        // BluetoothManager.
        if (PhoneBltClass.mBluetoothManager == null) {
            PhoneBltClass.mBluetoothManager = (BluetoothManager) ((Activity)context).getSystemService(Context.BLUETOOTH_SERVICE);
            if (PhoneBltClass.mBluetoothManager == null) {
                displayToast ( "Unable to initialize BluetoothManager.");
                return false;
            }

        }
        if (mBluetoothAdapter == null) {
            mBluetoothAdapter = PhoneBltClass.mBluetoothManager.getAdapter();
            if (mBluetoothAdapter == null) {
                displayToast("Unable to obtain a BluetoothAdapter.");
                return false;
            }
        }
        //displayToast ("Bluetooth Adapter ok");
        //  setconnectionState(STATE_CONNECTED);
        return true;
    }

    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        displayToast ("mBluetoothGatt closed");
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    private final BluetoothGattCallback mBluetoothGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
             if (newState == BluetoothProfile.STATE_CONNECTED) {
                connectionState = STATE_CONNECTED;
                setconnectionState(STATE_CONNECTED);
                gatt.discoverServices();
                //    broadcastUpdate(ACTION_GATT_CONNECTED);
            }

        }

           @Override
            public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
               broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED, gatt);
            }else{
                mBluetoothGatt.close();
                connectionState = STATE_DISCONNECTED;
            }

        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {
            setItems( "onDescr , ok");
            if (status == BluetoothGatt.GATT_SUCCESS) {
                displayToast ("onCharacteristicRead()");
                displayToast ("On thread: " + Thread.currentThread().getName());
                byte[] value = characteristic.getValue();
                StringBuilder sb = new StringBuilder();
                for (byte b : value) {
                   sb.append(String.format("%02X", b));
                }
                displayToast ("Read characteristic value: " +  sb.toString());
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            setItems( "Changed "+  characteristic.getUuid().toString());
            setItems( "Charac " + characteristic.getUuid().toString());
            broadcastUpdate(ACTION_DATA_AVAILABLE, gatt , characteristic);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt,
                                          BluetoothGattCharacteristic
                                                  characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                setItems( "Success " + characteristic.getUuid().toString() + status);
            }

        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status){
//            BluetoothGattCharacteristic characteristic =   gatt.getService(UART_SERVICE_UUID)
//                            .getCharacteristic(TX_CHAR_UUID);
//            characteristic.setValue(new byte[]{1, 1});
            setItems( "onDescr, ok");
//            gatt.writeCharacteristic(characteristic);
        }
    };

    private void broadcastUpdate(final String action,  final BluetoothGatt gatt) {
        final Intent intent = new Intent(action);
        if(ACTION_GATT_SERVICES_DISCOVERED.equals(action)){
            setItems( "Gatt Discovred , Success");
            setconnectionState(STATE_CONNECTED);
            connectionState = STATE_CONNECTED;

            for (BluetoothGattService service : mBluetoothGatt.getServices()) {
                String s = service.getUuid().toString();
                setItems( "UUID" + s.toString());
            }

        } else {
            setItems( "Error, UUID: ");
            setconnectionState(STATE_DISCONNECTED);
            connectionState = STATE_DISCONNECTED;

        }

        if(connectionState ==STATE_CONNECTED) {
            readDataNotif();
        }

    }

//    private void broadcastUpdate(final String action) {
//        final Intent intent = new Intent(action);
//
//        if (ACTION_GATT_CONNECTED.equals(action)) {
//            connectionState = STATE_CONNECTED;
//            setconnectionState(STATE_CONNECTED);
//            displayToast ("Connected" + mBluetoothGatt.discoverServices());
//            setItems( "GATT, Connected");
//
//        }
//        if (ACTION_GATT_DISCONNECTED.equals(action)) {
//            setconnectionState(STATE_DISCONNECTED);
//            displayToast ("ACTION_GATT_DISCONNECTED");
//        }
//        if (ACTION_GATT_CONNECTING.equals(action)) {
//            setconnectionState(STATE_CONNECTING);
//            displayToast ("Trying to activity_connect");
//        }
//        intent.putExtra(EXTRA_DATA, "");
//    }


    private void broadcastUpdate(final String action, final BluetoothGatt gatt,
                                 final BluetoothGattCharacteristic characteristic ) {
        final Intent intent = new Intent(action);

        if(ACTION_DATA_AVAILABLE.equals(action)) {
            descriptor();
            getDataFromGatt(intent, characteristic);

        }else{
            displayToast ("No action found");
        }


    }


    public void getDataFromGatt(Intent intent, final BluetoothGattCharacteristic characteristic){
        setItems( "We got data " );
        setItems( "UUID" + characteristic.getUuid());
        setItems( "RX_CHAR" + RX_CHAR );

        if (RX_CHAR.equals(characteristic.getUuid().toString())) {
            int flag = characteristic.getProperties();
            setItems( "flag:" + flag);
            // intent.putExtra(EXTRA_DATA, "Received");

            final byte[] data = characteristic.getValue();
            if (data != null && data.length > 0) {
                final StringBuilder stringBuilder = new StringBuilder(data.length);
                for (byte byteChar : data) {
                    stringBuilder.append((char)byteChar);
                }
                String msg = new String(stringBuilder);
               // setItems( "Data: ", new String(stringBuilder));
                setItems( "Data " + msg);
                setmsg(msg);
                intent.putExtra(EXTRA_DATA, new String(data) + "\n" + stringBuilder.toString());
            }
        }
      }

    public void readDataNotif(){

        if (connectionState !=STATE_CONNECTED || mBluetoothGatt == null) {
            displayToast ( "Cant activity_connect from BLE, not initialized." + connectionState);
            return;
        }

        displayToast ("* Getting gatt service, UUID:" + UART_SERVICE_UUID.toString());
        mBluetoothGattService = mBluetoothGatt.getService(UART_SERVICE_UUID);
        setItems( "Gatt " + mBluetoothGattService.toString());

        if (mBluetoothGattService != null) {
            CharRX = mBluetoothGattService.getCharacteristic(RX_CHAR_UUID);
            if (CharRX != null) {
                mBluetoothGatt.readCharacteristic(CharRX);
                boolean stat = mBluetoothGatt.setCharacteristicNotification(CharRX, true);
                setItems( "CharRX" + CharRX.getUuid().toString());
                setItems( "Char Notif Rx" + stat);
            }

            CharTX = mBluetoothGattService.getCharacteristic(TX_CHAR_UUID);
            if (CharTX != null) {
                // second parametes is for starting\stopping the listener.
                mBluetoothGatt.readCharacteristic(CharTX);
                boolean stat = mBluetoothGatt.setCharacteristicNotification(CharTX, true);
                setItems( "CharTX" + CharTX.getUuid().toString());
                setItems( "Char Notif TX" + stat);
            }



        }

    }

    public void writeDataNotif(String value) {
         if (connectionState !=STATE_CONNECTED || mBluetoothGatt == null) {
             displayToast ( "Cant write to BLE, not initialized." + connectionState);
             return;
         }
      //   displayToast ("* Getting gatt service, UUID:" + UART_SERVICE_UUID.toString());
         mBluetoothGattService =  mBluetoothGatt.getService(UART_SERVICE_UUID /*UUID_SERVICE*/);

         if (mBluetoothGattService != null) {
     //       displayToast ("* Getting gatt Characteristic. UUID: " + RX_CHAR_UUID.toString());
            CharRX = mBluetoothGattService.getCharacteristic(RX_CHAR_UUID);
            if (CharRX != null) {
               boolean stat = mBluetoothGatt.setCharacteristicNotification(CharRX, true);
               setItems( "CharRX" + CharRX.getUuid().toString());
               setItems( "Char Notif Rx" + stat);
               CharRX.setValue(value /*Consts.BYTE_NEW_HEART_RATE_SCAN*/);
               boolean status =  mBluetoothGatt.writeCharacteristic(CharRX);
               setItems( "* Writting trigger status :" + status);
            }
         }
    }

    public void descriptor() {
        CharTX = mBluetoothGattService.getCharacteristic(TX_CHAR_UUID);
        if (CharTX != null) {
            // second parametes is for starting\stopping the listener.
            boolean stat = mBluetoothGatt.setCharacteristicNotification(CharTX, true);
            setItems( "CharTX" + CharTX.getUuid().toString());
            setItems( "Char Notif TX" + stat);


            descriptor = CharTX.getDescriptor(UUID_DESCRIPTOR);
            setItems( "DescTX" + descriptor.getUuid() );
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            mBluetoothGatt.writeDescriptor(descriptor);
            setItems( "desc val" + descriptor.getValue().toString());
        }
        }


    private void setPin(BluetoothDevice device, String pin) {
        if (device == null || pin == null || pin.length() < 4)
            return;

        try {
            device.setPin(pin.getBytes("UTF8"));
        } catch (Exception e) {
            displayToast ("setPin ignoring: " + e);
        }
    }




    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }


     public void scanLeDevice(final boolean enable) {
        if (enable) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT < 21) {
                        mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    } else {
                        mLEScanner.stopScan(mScanCallback);
                    }
                }
            }, SCAN_PERIOD);
            if (Build.VERSION.SDK_INT < 21) {
                mBluetoothAdapter.startLeScan(mLeScanCallback);
            } else {
                mLEScanner.startScan(filters, settings, mScanCallback);
            }
        } else {
            if (Build.VERSION.SDK_INT < 21) {
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            } else {
                mLEScanner.stopScan(mScanCallback);
            }
        }
    }


    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
          //  Log.w(TAG, String.valueOf(callbackType));

            btDevice = result.getDevice();
            if(btDevice.getAddress() == "24:0A:C4:32:32:5E") {
                connect(btDevice);
            }

        }

    @Override
    public void onBatchScanResults(List<ScanResult> results) {
            for (ScanResult sr : results) {
                displayToast (sr.toString());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            displayToast ("Error Code: " + errorCode);
        }

    };

    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(final BluetoothDevice device, int rssi,
                                     byte[] scanRecord) {
                    ((Activity)context).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            displayToast (device.toString());
                        }
                    });
                }
            };



    String Items = "";

    public String getItems() {
        return Items;
    }

    public void setItems(String Items) {
        this.Items = Items;
        if (listener != null) listener.onChange("listViewChange");
    }


    String msg="";

    public String getmsg() {
        return msg;
    }

    public void setmsg(String msg) {
        this.msg = msg;
        if (listener != null) listener.onChange("msgChange");
    }


    public int getconnectionState() {
        return connectionState;
    }

    public void setconnectionState(int connectionState) {
        this.connectionState = connectionState;
        if (listener != null) listener.onChange("connectionStatusChange");
    }


    private ChangeListener listener;

    public void setListener(ChangeListener listener) {
        this.listener = listener;
    }

    public interface ChangeListener {
        void onChange(String s);

    }

    public ChangeListener getListener() {
        return listener;
    }


}
