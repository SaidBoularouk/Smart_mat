package com.example.myapplication;

import android.util.Pair;

import java.security.Key;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class dictionnary {

    public static HashMap<String, Prayer> getMap() {
        fillMap();
        return map;
    }

    public static void setMap(HashMap<String, Prayer> map) {
        dictionnary.map = map;
    }

    private static HashMap<String, Prayer > map =
          new HashMap<String, Prayer >();


    public static  void fillMap(){
        Prayer fajr = new Prayer();
        fajr.setTitle( "fajr");
        fajr.setNbrRaqa("2");

        Prayer duhr = new Prayer();
        duhr.setTitle("duhr");
        duhr.setNbrRaqa("4");

        Prayer asr = new Prayer();
        asr.setTitle("asr");
        asr.setNbrRaqa("4");

        Prayer maghrib = new Prayer();
        maghrib.setTitle("maghrib");
        maghrib.setNbrRaqa("3");

        Prayer isha = new Prayer();
        isha.setTitle("isha");
        isha.setNbrRaqa("4");

        Prayer shaf = new Prayer();
        shaf.setTitle("shaf");
        shaf.setNbrRaqa("2");

        Prayer watr = new Prayer();
        watr.setTitle("watr");
        watr.setNbrRaqa("1");

        Prayer free_2 = new Prayer();
        duhr.setTitle("free_2");
        fajr.setNbrRaqa("2");

        Prayer free_4 = new Prayer();
        duhr.setTitle("free_4");
        fajr.setNbrRaqa("4");


        map.put("fajr", fajr);
        map.put("duhr", duhr);
        map.put("asr", asr);
        map.put("maghrib", maghrib);
        map.put("isha", isha);
        map.put("shaf", shaf);
        map.put("watr", watr);
        map.put("free_2", free_2);
        map.put("free_4", free_4);
    }



}
