package com.example.myapplication;

import android.content.Context;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.RadarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Color;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import static android.view.View.*;

public class chartActivity extends AppCompatActivity {
    BarData barData;
    BarDataSet barDataSet;
    ArrayList barEntries = new ArrayList();
    xmlclass xmlClass;
    Context context;
    TextView txt;
    ConstraintLayout main;
    BarChart barChart;
    LinearLayout verticalayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        context = this.getApplicationContext();

        txt = (TextView) findViewById(R.id.textView);
        xmlclass xmlClass = new xmlclass(context);

        main = (ConstraintLayout) findViewById(R.id.content);
        verticalayout = (LinearLayout) findViewById(R.id.vertical);


        ConstraintLayout chartLayout = (ConstraintLayout) findViewById(R.id.chartLayout);
        ConstraintSet set = new ConstraintSet();

//
//        if (entries() != null) {
//            for (List<ArrayList> element : entries()) {
//                for (ArrayList el : element) {
//                    barChart = new BarChart(this);
//                    barEntries = el;
//                    createRow(el, "");
//
//                }
//            }
//        }

        String date="", s = "";
    if (xmlClass.getnodes(null) != null) {

         for (ArrayList<Prayer> listP : xmlClass.getnodes("date")) {
              for (Prayer p : listP) {
                  if(date != p.getToayDate()) {
                      date = p.getToayDate();
                      createRowDate(p.getToayDate(), 24);
                  }
                  createRow(getCrhono(p.getRunningTime()), "Salat: "+p.getTitle(), "Time: "+ p.getPrayerDate(), true);
              s +=  p.getTitle();
              }
         }
      }
txt.setText(s);
 }

    LinearLayout horizontalLayout;
    private void createRow(ArrayList barEntries, String title, String date, Boolean ischecked) {
        horizontalLayout = new LinearLayout(this);
        LinearLayout.LayoutParams horizontalParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        horizontalLayout.setOrientation(LinearLayout.HORIZONTAL);
        horizontalLayout.setLayoutParams(horizontalParams);
        horizontalParams.setMargins(10, 10, 10, 10);
        horizontalLayout.setGravity(Gravity.CENTER);
        createBarChar(barEntries);
        createColumn(title, date, ischecked);
        verticalayout.addView(horizontalLayout);
    }

    LinearLayout columnLayout;
    private void createColumn(String title, String date, Boolean ischecked) {
        columnLayout = new LinearLayout(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        columnLayout.setOrientation(LinearLayout.VERTICAL);
        params.setMargins(5, 0, 5, 0);
        params.gravity = Gravity.LEFT;
        columnLayout.setLayoutParams(params);
        createCheckbox(ischecked);
        createTextView(title);
        createTextView(date);
        horizontalLayout.addView(columnLayout);
    }


    private void createBarChar(ArrayList barEntries) {
      BarChart chart = new BarChart(this);

      LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        chart.setLayoutParams(params);
        BarDataSet barDataSet = new BarDataSet(barEntries, "");
        barData = new BarData(barDataSet);
        chart.setData(barData);
        barDataSet.setColors(ColorTemplate.JOYFUL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(10f);
        barDataSet.setBarBorderWidth(1f);
        chart.setMinimumWidth(600);
        chart.setMinimumHeight(300);
        horizontalLayout.addView(chart);
    }
    private void createCheckbox(Boolean ischecked) {

        CheckBox checkBox = new CheckBox(this);
        LinearLayout.LayoutParams checkParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        checkParams.gravity = Gravity.LEFT;
        checkBox.setLayoutParams(checkParams);
        checkBox.setText("Done");
        checkBox.setTextSize(10);
        checkBox.setChecked(ischecked);
        columnLayout.addView(checkBox);
    }

    private void createTextView(String title) {
        TextView txt = new TextView(this);
         LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.LEFT;
        txt.setLayoutParams(params);
        txt.setText(title);
        txt.setTextSize(10);
        txt.setTextColor(Color.BLACK);
        columnLayout.addView(txt);
    }

    private void createTitleDate(String title, int font) {
        TextView txt = new TextView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.CENTER;
        txt.setGravity(Gravity.CENTER);
        txt.setLayoutParams(params);
        txt.setTextSize(font);
        txt.setText(title);
        horizontalLayout.addView(txt);
    }

    private void createRowDate(String title, int font) {
        horizontalLayout = new LinearLayout(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        horizontalLayout.setOrientation(LinearLayout.HORIZONTAL);
        horizontalLayout.setLayoutParams(params);
        params.setMargins(0,10,0,50);
        createTitleDate(title, font);
        verticalayout.addView(horizontalLayout);
    }
    private ArrayList<BarEntry> getCrhono(String runningTime) {
        ArrayList barEntries = new ArrayList<>();
        String[] running = runningTime.split(",");

        String s="";
        for (int i = 0; i < running.length; i++) {
            barEntries.add(new BarEntry( i+1, Integer.valueOf(running[i].trim()).intValue()));
        }
        return  barEntries;
    }

//    private List<List<ArrayList>> entries(){
//        xmlclass xmlClass = new xmlclass(context);
//         List<ArrayList> ArraybarEntries = new ArrayList();
//         List list = new ArrayList();
//        if(xmlClass.getnodes("date") != null) {
//            for (ArrayList<Prayer> listP: xmlClass.getnodes("date")) {
//                for(Prayer p: listP) {
//                    getCrhono(p.getRunningTime());
//                    ArraybarEntries.add(getCrhono(p.getRunningTime()));
//                }
//                list.add(ArraybarEntries);
//            }
//        }
//        return  list;
//    }




}
