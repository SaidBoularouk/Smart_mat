package com.example.myapplication;

import java.util.Calendar;
import java.util.Date;

public class Prayer {

    public Prayer(){
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    String title="";


    public String getToayDate() {
        return todayDate;
    }

    public void setTodayDate(String date) {
        this.todayDate = date;
    }

    String todayDate = "";


    public String getNbrRaqa() {
        return nbrRaqa;
    }

    public void setNbrRaqa(String nbrRaqa) {
        this.nbrRaqa = nbrRaqa;
    }

    String nbrRaqa = "";


    public String getNbrSajda() {
        return nbrSajda;
    }

    public void setNbrSajda(String nbrSajda) {
        this.nbrSajda = nbrSajda;
    }

    String nbrSajda = "";


    public String getRunningTime() {
        return RunningTime;
    }

    public void setRunningTime(String RunningTime) {
        this.RunningTime = RunningTime;
    }

    String RunningTime = "";


    public String getPrayerDate() {
        return prayerDate;
    }

    public void setPrayerDate(String datePrayer) {
        this.prayerDate = datePrayer;
    }

    public String prayerDate="";


    public String getTotalDuration() {
        return totalDuration;
    }

    public void setTotalDuration(String totalDuration) {
        this.totalDuration = totalDuration;
    }

    String totalDuration="";

    public String getMinPrayerTime() {
        return minPrayerTime;
    }

    public void setMinPrayerTime(String minPrayerTime) {
        this.minPrayerTime = minPrayerTime;
    }

    String minPrayerTime="";

    public String getMaxPrayerTime() {
        return maxPrayerTime;
    }

    public void setMaxPrayerTime(String maxPrayerTime) {
        this.maxPrayerTime = maxPrayerTime;
    }

    String maxPrayerTime="";


}
