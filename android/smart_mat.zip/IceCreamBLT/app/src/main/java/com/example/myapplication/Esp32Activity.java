package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Chronometer;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ToggleButton;

import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

@TargetApi(21)
public class Esp32Activity extends AppCompatActivity {

    private BluetoothAdapter mBluetoothAdapter;
    private int REQUEST_ENABLE_BT = 1;
    private Handler mHandler;

    private TextView  txtViewDate, txtViewTime, txtViewTimer,
            txtViewRaqa, txtViewSajda, txtViewChoise;
    private ListView lvw;

    private Context context;
    private BluetoothDevice device;


    private String mBluetoothDeviceAddress;

    private static ArrayAdapter<String> adapter;
    private static ArrayList<String> listItems=new ArrayList<String>();


    private ToggleButton startStop;
    private Boolean TogglestartStop;

    private  AlertDialog.Builder dlg;


    private Map<String, String> time = new HashMap<>();

    private TextView txtStartSalat, txtraq1, txtraq2, txtraq3, txtraq4, txtEndSalat;

    private  ArrayList<TextView> ArrayTextV = new ArrayList<TextView>();

    private  boolean salatSeleted = false;

    private  int nbrRaqa =0;

    /*
    *Add classses
    */
    dateTime date_Time ;
    BluetoothDevice btDevice;
    esp32class connect_Device;
    dictionnary dict;

    /**chrono**/
    Chronometer simpleChronometer;

    xmlclass xmlClass;
    // Create prayerOjject
    Prayer p = new Prayer();
    String dateprayer, timeprayer, nameprayer;
    private Drawable rwb_gray, rwb ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_le_activity);
        //Keep screen on
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar); //No Problerm;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mHandler = new Handler();
        context = this.getApplicationContext();

        txtViewDate = (TextView) findViewById(R.id.textVieWDate);
        txtViewTime = (TextView) findViewById(R.id.textVieWTime);
        txtViewRaqa = (TextView) findViewById(R.id.raqa);
        txtViewSajda = (TextView) findViewById(R.id.sajda);
        txtViewTimer =(TextView) findViewById(R.id.timer);
        txtViewChoise = (TextView) findViewById(R.id.choise);

        txtStartSalat = (TextView) findViewById(R.id.textStart);
        txtEndSalat = (TextView) findViewById(R.id.textEnd);
        txtraq1 = (TextView) findViewById(R.id.textR1);
        txtraq2 = (TextView) findViewById(R.id.textR2);
        txtraq3 = (TextView) findViewById(R.id.textR3);
        txtraq4 = (TextView) findViewById(R.id.textR4);

        rwb_gray = ContextCompat.getDrawable(context, R.drawable.textview_circle_gray);
        rwb = ContextCompat.getDrawable(context, R.drawable.textview_circle);

        salatSeleted = false;
        ArrayTextV.add(txtraq1);
        ArrayTextV.addAll(new ArrayList<>(Arrays.asList(txtraq1,txtraq2, txtraq3, txtraq4) ));
        clearRaq();

        dict = new dictionnary();

        xmlclass xmlClass = new xmlclass(context);
        date_Time = new dateTime();
        p = new Prayer();

        dateprayer = date_Time.date();

        simpleChronometer = (Chronometer) findViewById(R.id.simpleChronometer);
        simpleChronometer.setText("00:00:00");

        date_Time.setSimpleChronometer(simpleChronometer);
        startStop = (ToggleButton) findViewById(R.id.startStop);

        startStop.setEnabled(false);

        TogglestartStop = startStop.isChecked();

        startStop.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    if(salatSeleted) {
                       startStop.setTextOn("Prayer Started");
                       startStop.setBackgroundColor(Color.parseColor("#038A06"));
                       startStop.setTextColor(Color.WHITE);
                       connect_Device.connect(device);
                       connect_Device.readDataNotif();
                       txtStartSalat.setBackground(rwb);
                       date_Time.startChrono(date_Time.getSimpleChronometer());
                       timeprayer = date_Time.time();
                    }
                    } else {
                    if(salatSeleted) {
                       startStop.setTextOff("Prayer ended");
                       startStop.setBackgroundColor(Color.parseColor("#CE0101"));
                       startStop.setTextColor(Color.WHITE);
                       initialiseRaq(nbrRaqa);
                       p.setTotalDuration(date_Time.getTotalDuration());
                      date_Time.stopChrono();
                    }

                }
            }
        });


    if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
         Toast.makeText(this, "BLE Not Supported",
                Toast.LENGTH_SHORT).show();
         finish();
    }
    final BluetoothManager bluetoothManager =
             (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if(PhoneBltClass.mBluetoothAdapter !=null) {
          mBluetoothAdapter = PhoneBltClass.mBluetoothAdapter;
    }

    connect_Device = new esp32class(this, mHandler);

    lvw = (ListView) findViewById(R.id.listview1);
    adapter=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, listItems);
    lvw.setAdapter(adapter);
    listItems.add("values");
    adapter.notifyDataSetChanged();


    mBluetoothDeviceAddress = PhoneBltClass.getDevice().getAddress();
    device = PhoneBltClass.getDevice();

    connect_Device.connect(device);

    xmlClass.createFile();
    xmlClass.writeXml();

    p.setTodayDate("date");
    p.setTitle("prayer");
    p.setPrayerDate("14h");
    p.setNbrRaqa("4");
    p.setNbrSajda("8");
    p.setRunningTime("23,45,67,25,32,74,41,37");
    xmlClass.add(p);

    adapter.notifyDataSetChanged();

    p.setTodayDate("date");
    p.setTitle("prayer3");
    p.setPrayerDate("14h");
    p.setNbrRaqa("2");
    p.setNbrSajda("4");
    p.setRunningTime("3,74,71,17");
    xmlClass.add(p);

    adapter.notifyDataSetChanged();

        p.setTodayDate("date");
        p.setTitle("prayer2");
        p.setPrayerDate("14h");
        p.setNbrRaqa("2");
        p.setNbrSajda("4");
        p.setRunningTime("32,7,41,77");
        xmlClass.add(p);

        adapter.notifyDataSetChanged();

    date_Time.setTime(txtViewTime);
    date_Time.setDate(txtViewDate);


//     // In a real app you should check first if bluetooth is enabled first
//     bt_read.setOnClickListener(new View.OnClickListener() {
//         @Override
//         public void onClick(View v) {
//             connect_Device.readDataNotif();
//        }
//     });
//     // In a real app you should check first if bluetooth is enabled first
//
//      /**
//       * Listner
//      */
      Listner();
    }

    private void reconnect(){
       connect_Device.writeDataNotif("salam");
    }

    public Dialog createNewDialog(Context context, String title, String msg) {
        AlertDialog dlg = new AlertDialog.Builder(context)
                        .setTitle(title)
                        .setMessage(msg)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                             @Override
                             public void onClick(DialogInterface dialog, int which) {
                                connect_Device.writeDataNotif("none");
                             }
                        }).create();
        return  dlg;
    }

    @Override
    protected void onResume() {
       super.onResume();
       if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
           Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
           startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
       } else {

      }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
            //     scanLeDevice(false);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    //METHOD WHICH WILL HANDLE DYNAMIC INSERTION
    public void addItems(final String d, final String s) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String l = d +": " + s;
                if(!listItems.contains(l)) {
                    listItems.add(l);
                }
                adapter.notifyDataSetChanged();
            }
        });

    }

    private void Listner() {
        final int[] raq = {0};
        final int[] saj = {0};
        final int[] timer = {0};
        connect_Device.setListener(new esp32class.ChangeListener() {
            @Override
            public void onChange(String s) {
                int i=0;
                switch (s) {
                    case "listViewChange":
                        addToList(connect_Device.getItems());
                    break;

                     case "msgChange":
                        String msg = connect_Device.getmsg();
                        if(msg.charAt(0)=='#' && msg.charAt(msg.length()-2)=='$') {
                           String _msg = msg.substring(1, msg.length() - 2);
                           if (_msg.contains("salam")) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                    createNewDialog(Esp32Activity.this, "Bluetooth connection", "Success Dialogue with Carpet").show();
                                    }
                                });
                           }
                           if (_msg.contains("none")) {
                              runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    createNewDialog(Esp32Activity.this,"Bluetooth connection", "Success Dialogue with Carpet" ).hide();
                                  }
                              });
                            }
                            if(_msg.contains("~")){
                                String[] rst = _msg.split("~");
                                txtViewRaqa.setText(rst[0]);
                                raq[i] = Integer.parseInt(rst[0]);
                                txtViewSajda.setText(rst[1]);
                                saj[i] = Integer.parseInt(rst[1]);
                                txtViewTimer.setText(rst[2]);
                                timer[i] = Integer.parseInt(rst[2]);
                                time.put("Sajda" + rst[0], rst[2]);
                                showRaq(rst[i]);
                                i++;

                                if(raq[i]== nbrRaqa){
                                    txtEndSalat.setBackground(rwb);

                                    p.setTodayDate(dateprayer);  // Add date to prayer Object
                                    p.setPrayerDate(timeprayer); // Add to prayer object
                                    p.setTitle(nameprayer);      // Add name pf prayer
                                    p.setNbrRaqa(raq[i]+"");        // Add nmbr raqaa
                                    p.setNbrSajda(saj[i]+"");       // Add nmr nbrSajda
                                    p.setRunningTime(Arrays.toString(timer));
                                    p.setTodayDate(date_Time.getTotalDuration());
                                    xmlClass.add(p);

                                }
                            }
                        }
                        break;

                    case"connectionStatusChange":
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                             Toast.makeText(Esp32Activity.this, "BLE is connected", Toast.LENGTH_SHORT).show();
                            }
                        });
                    break;

                    default:
                        throw new IllegalStateException("Unexpected value: " + s);
                }
            }
       
        });

    }


    //METHOD WHICH WILL HANDLE DYNAMIC INSERTION
    public void addToList(final String s) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                 if(!listItems.contains(s)) {
                    listItems.add(s);
                    lvw.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }

            }
        });

    }

    /**
     *
     * @param @Menu region
     * @param menu
     * @return
     */

    @Override
    public boolean onMenuOpened(int featureId, Menu menu){
        if(featureId == Window.FEATURE_ACTION_BAR && menu != null){
            if(menu.getClass().getSimpleName().equals("MenuBuilder")){
                try{
                    Method m = menu.getClass().getDeclaredMethod(
                            "setOptionalIconsVisible", Boolean.TYPE);
                    m.setAccessible(true);
                    m.invoke(menu, true);
                }
                catch(NoSuchMethodException e){
                    //   Log.e(TAG, "onMenuOpened", e);
                }
                catch(Exception e){
                    throw new RuntimeException(e);
                }
            }
        }
        return super.onMenuOpened(featureId, menu);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        if(menu instanceof MenuBuilder){
            MenuBuilder m = (MenuBuilder) menu;
            m.setOptionalIconsVisible(true);
        }

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Toast.makeText(this, "Selected Item: " +item.getTitle(), Toast.LENGTH_SHORT).show();
        nameprayer = item.toString();
        switch (item.getItemId()) {
            case R.id.reconnect:
                // do your code
                connect_Device.initialize();
                connect_Device.connect(device);
                connect_Device.readDataNotif();
                salatSeleted = false;
                startStop.setEnabled(false);
                return true;

            case R.id.test:
                // do your code
                reconnect();
                return true;

            case R.id.fajr:
            case R.id.duhr:
            case R.id.asr:
            case R.id.maghrib:
            case R.id.isha:
            case R.id.shaf:
            case R.id.watr:
            case R.id.free_2:
            case R.id.free_4:
                caseSelectPrayer((String) item.getTitle());
                return true;

            case R.id.disconnect:
                // do your code
                salatSeleted = false;
                connect_Device.disconnect();
                connect_Device.close();
                startStop.setEnabled(false);
                salatSeleted = false;
                return true;

            case R.id.stats:
                // do your code
                Intent intent = new Intent(Esp32Activity.this, chartActivity.class);
                startActivity(intent);
                return true;

            case R.id.cloud:
                // do your code
                return true;

            case R.id.help:
                // do your code
                return true;

            case R.id.quit:
                // do your code
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }


    }


//    private void startChrono(){
//        simpleChronometer.setBase(SystemClock.elapsedRealtime());
//        simpleChronometer.stop();
//        simpleChronometer.start();
//        simpleChronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
//            @Override
//            public void onChronometerTick(Chronometer chronometer) {
//                long systemCurrTime = SystemClock.elapsedRealtime();
//                long chronometerBaseTime = chronometer.getBase();
//                long time = systemCurrTime - chronometerBaseTime;
//                if(time > 10000)
//                {
//                    int h   = (int)(time /3600000);
//                    int m = (int)(time - h*3600000)/60000;
//                    int s= (int)(time - h*3600000- m*60000)/1000 ;
//                    totalDuration = (h < 10 ? "0"+h: h)+":"+(m < 10 ? "0"+m: m)+":"+ (s < 10 ? "0"+s: s);
//                    chronometer.setText(totalDuration);
//                }
//            }
//        });
//
//    }
//
//
//    private void stopChrono(){
//        simpleChronometer.stop();
//    }


    private void caseSelectPrayer(String salat){
        clearRaq();
        if(dictionnary.getMap() !=null) {
           if(dictionnary.getMap().containsKey(salat.toLowerCase())) {
               Prayer p = dictionnary.getMap().get(salat.toLowerCase());
               if (p != null) {
                   txtViewChoise.setText(salat.toString());
                   nbrRaqa = Integer.valueOf(p.getNbrRaqa());
                   txtViewTimer.setText(nbrRaqa+"");
                   connect_Device.writeDataNotif("n" + nbrRaqa + "r");
                   initialiseRaq(nbrRaqa);
                   startStop.setEnabled(true);
               }
               salatSeleted = true;
           }
        }


    }
    private void showRaq(String rq){
        int r = Integer.parseInt(rq);
        txtStartSalat.setBackground(rwb_gray);
        for(TextView t : ArrayTextV){
            t.setBackground(rwb_gray);
        }
        TextView txv = ArrayTextV.get(r);
        txv.setVisibility(View.VISIBLE);
        txv.setBackground(rwb);

    }

    private void initialiseRaq(int rq){
        txtStartSalat.setVisibility(View.VISIBLE);
        txtEndSalat.setVisibility(View.VISIBLE);

        txtStartSalat.setBackground(rwb_gray);
        txtEndSalat.setBackground(rwb_gray);
        for(int r=1; r <= rq; r++) {
            TextView txv = ArrayTextV.get(r);
            txv.setVisibility(View.VISIBLE);
            txv.setBackground(rwb_gray);
        }

    }

    private void  clearRaq(){
        txtStartSalat.setVisibility(View.INVISIBLE);
        txtraq1.setVisibility(View.INVISIBLE);
        txtraq2.setVisibility(View.INVISIBLE);
        txtraq3.setVisibility(View.INVISIBLE);
        txtraq4.setVisibility(View.INVISIBLE);
        txtEndSalat.setVisibility(View.INVISIBLE);
    }


//    private void showdiagram(int rq){
//        Drawable rwb = ContextCompat.getDrawable(context, R.drawable.textview_circle);
//
//        txtStartSalat.setVisibility(View.VISIBLE);
//        txtStartSalat.setBackground(rwb);
//
//        txtEndSalat.setVisibility(View.VISIBLE);
//        txtEndSalat.setBackground(rwb);
//
//        for(int r=1; r <= rq; r++) {
//            TextView txv = ArrayTextV.get(r);
//            txv.setVisibility(View.VISIBLE);
//            txv.setBackground(rwb);
//        }
//
//
//    }

    /**
     * End Menu
     */
}