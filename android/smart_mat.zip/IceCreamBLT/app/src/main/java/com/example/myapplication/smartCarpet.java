package com.example.myapplication;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Handler;
import android.os.Message;

import android.os.ParcelUuid;
import android.view.View;

import android.widget.TextView;
import android.widget.Toast;

import android.widget.Button;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


public class smartCarpet extends  AppCompatActivity { private PhoneBltClass phoneBltClass;
    private bluetooth _bluetooth;


    private int REQUEST_ENABLE_BT = 99, REQUEST_ENABLE_LOCATION = 457;
    private Button bt_read, bt_stop, bt_write, bt_connect;
    private TextView txtview;
    private final String nameofBluetooth = "SmartCarpet";
    private Context context;
    private BluetoothDevice device;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        context = this.getApplicationContext();

         phoneBltClass = new PhoneBltClass(this);


        _bluetooth = new bluetooth(this, mHandler);


        setContentView(R.layout.activity_le_activity);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });


        txtview = (TextView) findViewById(R.id.raqa);

        bt_connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _bluetooth.start();
                _bluetooth.connect(PhoneBltClass.getDevice());
                _bluetooth.sendMessage("Hello");
                phoneBltClass.displayToast("" + _bluetooth.getState());
                txtview.setText(_bluetooth.getState() + " , " + _bluetooth.getmsgState());
            }
        });

        // In a real app you should check first if bluetooth is enabled first
        bt_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



            }
        });

        // In a real app you should check first if bluetooth is enabled first
        bt_read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ParcelUuid[] phoneUuids =  null;
              //  txtview.setText(MyBluetoothClass.getDevice().getUuids() +"");
        //       phoneBltClass.connectDevice(MyBluetoothClass.getDevice());
                Method method = null;
                try {
                    method = PhoneBltClass.getDevice().getClass().getMethod("getUuids", null);
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                }
                try {
                    phoneUuids = (ParcelUuid[]) method.invoke(PhoneBltClass.getDevice(), null);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
                String s = "";
                for(ParcelUuid p : phoneUuids) {
                   s = p + "";
                }

                txtview.setText(s );
                phoneBltClass.connectToDevice(PhoneBltClass.getDevice());
            }
        });
        // In a real app you should check first if bluetooth is enabled first
        bt_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _bluetooth.stop();
            }
        });
    }

    private StringBuilder recDataString = new StringBuilder();

    private void arduinoMessage(Message msg) {
        String readMessage = (String) msg.obj;                          // msg.arg1 = bytes from activity_connect thread
        txtview.append(readMessage);                              //keep appending to string until ~
        int endOfLineIndex = recDataString.indexOf("~");                    // determine the end-of-line

        //     if (endOfLineIndex > 0) {                                           // make sure there data before ~
        String dataInPrint = recDataString.substring(0, endOfLineIndex);    // extract string

        txtview.setText("" + recDataString.toString());


        //     }
    }

    private final Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case bluetooth.MESSAGE_STATE_CHANGE:
                    txtview.setText("" + _bluetooth.getmsgState() + " , " + _bluetooth.getState());
                    break;
                case bluetooth.MESSAGE_WRITE:
                    Toast.makeText(smartCarpet.this, "MESSAGE_WRITE ", Toast.LENGTH_SHORT).show();
                    txtview.setText("MESSAGE WRITE");
                    _bluetooth.sendMessage("Hello");
                    break;
                case bluetooth.MESSAGE_READ:
                    arduinoMessage(msg);
                    Toast.makeText(smartCarpet.this, "MESSAGE_READ", Toast.LENGTH_SHORT).show();
                    break;
                case bluetooth.MESSAGE_DEVICE_NAME:
                    Toast.makeText(smartCarpet.this, "MESSAGE_DEVICE_NAME " + msg, Toast.LENGTH_SHORT).show();
                    break;
                case bluetooth.MESSAGE_TOAST:
                    Toast.makeText(smartCarpet.this, "MESSAGE_TOAST " + msg, Toast.LENGTH_SHORT).show();

                    break;
            }
        }
    };


}
    /**
     *
         @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        phoneBltClass = new MyBluetoothClass(this);


        setContentView(R.layout.activity_Le);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });


        bt_enable_ble = (Button) findViewById(R.id.button_enableBT);
        bt_stop_scan = (Button) findViewById(R.id.stop_scan);
        bt_PairedBT = (Button) findViewById(R.id.button_alreadyPairedBT);
        bt_start_scan = (Button) findViewById(R.id.start_scan);
        bt_auto_connect = (Button) findViewById(R.id.bt_autoConnect);
        bt_visibility = (Button) findViewById(R.id.VisibilityBT);
        ListViewpairDevices = (ListView) findViewById(R.id.pairedDevices);
        ListViewFoundDevises = (ListView) findViewById(R.id.ListFoundDievices);
        txtview = (TextView) findViewById(R.id.textView);
        linlaHeaderProgress = (LinearLayout) findViewById(R.id.linlaHeaderProgress);

        adapterFoundDevices = new ArrayAdapter<BluetoothDevice>(smartCarpet.this,
                android.R.layout.simple_list_item_1, ListFoundDevices);

        adapterFoundDeviceNames = new ArrayAdapter<String>(smartCarpet.this,
                android.R.layout.simple_list_item_1, ListFoundDeviceNames);

        adapterPairedDevices = new ArrayAdapter<BluetoothDevice>(smartCarpet.this,
                android.R.layout.simple_list_item_1, ListPairedDevices);

        adapterPairedDeviceNames = new ArrayAdapter<String>(smartCarpet.this,
                android.R.layout.simple_list_item_1, ListPairedDeviceNames);

        ListViewFoundDevises.setAdapter(adapterFoundDeviceNames);
        ListViewpairDevices.setAdapter(adapterPairedDeviceNames);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();


       // phoneBltClass.setBt_start_scan(bt_start_scan);
      //  phoneBltClass.setLinlaHeaderProgress(linlaHeaderProgress);

        phoneBltClass.setListFoundDeviceNames(ListFoundDeviceNames);
        phoneBltClass.setListFoundDevices(ListFoundDevices);
        phoneBltClass.setListPairedDeviceNames(ListPairedDeviceNames);
        phoneBltClass.setListPairedDevices(ListPairedDevices);


        bt_enable_ble.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phoneBltClass.enableBluetoothOnDevice();
                IntentFilter filter = new IntentFilter();
                filter.addAction(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
                registerReceiver(phoneBltClass.mReceiverBluetooth, filter);
            }
        });

        bt_PairedBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBluetoothAdapter.isDiscovering()) {
                    phoneBltClass.displayToast("Canceling discovery.");
                    mBluetoothAdapter.cancelDiscovery();
                }
                phoneBltClass.PairedReceiver();
            }
        });

        // In a real app you should check first if bluetooth is enabled first
        bt_start_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phoneBltClass.displayToast("Looking for unpaired devices.");
                // On enregistre le "broadcast receiver" une unique fois
                if (mBluetoothAdapter.isDiscovering()) {
                    phoneBltClass.displayToast("Canceling discovery.");
                    mBluetoothAdapter.cancelDiscovery();
                }
                if (!mBluetoothAdapter.isDiscovering()) {
                    // On lance un nouveau scan bluetooth
                    mBluetoothAdapter.startDiscovery();
                }
                // Si un scan bluetooth est en cours, on le coupe
                checkBTPermissions();
                IntentFilter filter = new IntentFilter();
                filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
                filter.addAction(BluetoothDevice.ACTION_FOUND);
                filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
                registerReceiver(phoneBltClass.mSearchBleutoothReceiver, filter);
            }
        });

        bt_stop_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBluetoothAdapter.isDiscovering()) {
                    mBluetoothAdapter.cancelDiscovery();
                    bt_start_scan.setEnabled(true);
                }
            }
        });

        bt_visibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phoneBltClass.displayToast("Making device discoverable for 300 mseconds.");
                Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
                startActivity(discoverableIntent);
                IntentFilter intentFilter = new IntentFilter(mBluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
                registerReceiver(phoneBltClass.mScantReceiver, intentFilter);
            }
        });

        bt_auto_connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nameofBluetooth[0] = "Y635-L21";
      //          phoneBltClass.setSingleSerach(false);
                if (!ListPairedDeviceNames.isEmpty() && ListPairedDeviceNames.contains(nameofBluetooth[0])) {
                    //
                } else {
                    if (!ListFoundDeviceNames.isEmpty() && ListFoundDeviceNames.contains(nameofBluetooth[0])) {
                        int position = ListFoundDeviceNames.indexOf(nameofBluetooth[0]);
                        BluetoothDevice device = ListFoundDevices.get(position);
                        phoneBltClass.creadBond(device);
                    } else {
                        if (mBluetoothAdapter.isDiscovering()) {
                            phoneBltClass.displayToast("Canceling discovery.");
                            mBluetoothAdapter.cancelDiscovery();
                        } else {
                            // On lance un nouveau scan bluetooth
                            mBluetoothAdapter.startDiscovery();
                        }
                        // Si un scan bluetooth est en cours, on le coupe
                        //   checkBTPermissions();
                        IntentFilter filter = new IntentFilter();
                        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
                        filter.addAction(BluetoothDevice.ACTION_FOUND);
                        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
                        registerReceiver(phoneBltClass.mSearchBleutoothReceiver, filter);
                    }
                }
            }

        });

        ListItemClickedToPair();
        //Add listner to unpair
        ListItemClickedToUnPair();
        //Add listner MyBluetoothClass
        ListnerMybltClass();


    }

    private void checkBTPermissions() {
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP){
            int permissionCheck = 0;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                permissionCheck = this.checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION");

                permissionCheck += this.checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION");
                if (permissionCheck != 0) {
                    this.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_ENABLE_LOCATION); //Any number
                }
            }
        }else{
            phoneBltClass.displayToast("checkBTPermissions: No need to check permissions. SDK version < LOLLIPOP.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == 0) {
                Toast.makeText(this, "The user decided to deny bluetooth access", Toast.LENGTH_LONG).show();
            } else
                phoneBltClass.displayToast( "User allowed bluetooth access!");
        }
    }


    private void ListItemClickedToPair() {
        ListViewFoundDevises.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub
                mBluetoothAdapter.cancelDiscovery();
                phoneBltClass.displayToast("onItemClick: You Clicked on a device.");
                BluetoothDevice device = ListFoundDevices.get(position);
                String deviceName = device.getName();
                String deviceAddress = device.getAddress();
                //create the bond.
                phoneBltClass.creadBond(device);
                txtview.setText(deviceName +"  " + device + "  "+ deviceAddress + "  " + device.getUuids()  );
            }
        });
    }

    private void ListItemClickedToUnPair() {
        ListViewpairDevices.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // bdDevice = arrayListPairedBluetoothDevices.get(position);
                String selectedItem = (String) parent.getItemAtPosition(position);
                BluetoothDevice device = ListPairedDevices.get(position);
                Boolean result;
                if (phoneBltClass.removeBlond(device)){
                    ListPairedDevices.remove(device);
                    ListPairedDeviceNames.remove(device.getName());
                    ListFoundDevices.add(device);
                    ListFoundDeviceNames.add(device.getName());
                    adapterPairedDevices.notifyDataSetChanged();
                    adapterPairedDeviceNames.notifyDataSetChanged();
                    adapterFoundDeviceNames.notifyDataSetChanged();
                    adapterFoundDevices.notifyDataSetChanged();
                }
            }
        });
    }


    @Override
    protected void onDestroy() {
        phoneBltClass.displayToast("onDestroy: called.");
        super.onDestroy();
        try {
            //Register or UnRegister your broadcast receiver here
            unregisterReceiver(phoneBltClass.mReceiverBluetooth);
            unregisterReceiver(phoneBltClass.mScantReceiver);
            unregisterReceiver(phoneBltClass.mSearchBleutoothReceiver);
            unregisterReceiver(phoneBltClass.bondStateReceiver);
            //unregisterReceiver(mPairedChangeReceiver);
            mBluetoothAdapter.cancelDiscovery();
        } catch(IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected  void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, smartCarpet.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


    private void ListnerMybltClass(){
        phoneBltClass.setListener(new MyBluetoothClass.ChangeListener() {
            @Override
            public void onChange(String s) {

                switch (s){
                    case "stateBlAdapter": {
                        switch (phoneBltClass.getStateBlAdapter()) {

                            case BluetoothAdapter.STATE_OFF : {
                                bt_enable_ble.setBackgroundResource(R.drawable.icon_blte_off);
                                break;
                            }
                            case BluetoothAdapter.STATE_ON : {
                                bt_enable_ble.setBackgroundResource(R.drawable.icon_blte_on);
                                break;
                            }
                            case BluetoothAdapter.STATE_TURNING_OFF : {
                                bt_enable_ble.setBackgroundResource(R.drawable.icon_blte_on_off);
                                break;
                            }
                            case BluetoothAdapter.STATE_TURNING_ON:
                                bt_enable_ble.setBackgroundResource(R.drawable.icon_blte_on_off);
                                break;
                        }
                        break;
                    }
                    case "progress":{

                        if(phoneBltClass.getProgress())
                            linlaHeaderProgress.setVisibility(View.VISIBLE);
                        else
                            linlaHeaderProgress.setVisibility(View.GONE);
                        break;
                    }
                    case "bond":{
                        adapterPairedDevices.notifyDataSetChanged();
                        adapterPairedDeviceNames.notifyDataSetChanged();
                        adapterFoundDeviceNames.notifyDataSetChanged();
                        adapterFoundDevices.notifyDataSetChanged();
                        if(!phoneBltClass.getProgress())
                            linlaHeaderProgress.setVisibility(View.GONE);
                        break;
                    }
                    case "found":{
                        adapterPairedDevices.notifyDataSetChanged();
                        adapterPairedDeviceNames.notifyDataSetChanged();
                        adapterFoundDeviceNames.notifyDataSetChanged();
                        adapterFoundDevices.notifyDataSetChanged();
                        if(!phoneBltClass.getProgress())
                            linlaHeaderProgress.setVisibility(View.GONE);
                        break;
                    }
                    case "paired":{
                        adapterPairedDevices.notifyDataSetChanged();
                        adapterPairedDeviceNames.notifyDataSetChanged();
                        adapterFoundDeviceNames.notifyDataSetChanged();
                        adapterFoundDevices.notifyDataSetChanged();
                        if(!phoneBltClass.getProgress())
                            linlaHeaderProgress.setVisibility(View.GONE);

                        break;
                    }
                    case "singleSearch":{
//                        if(phoneBltClass.getSingleSerach()==true) {
//                            nameofBluetooth[0] = "Y635-L21";
//                            BluetoothDevice device = null;
//                            int position = 0;
//                            boolean exist = false;
//                            String str = "";
//
//                            txtview.setText(nameofBluetooth[0]);
//                            if (phoneBltClass.getScanState()) {
//                                if (phoneBltClass.getListFoundDeviceNames().contains(nameofBluetooth[0])) {
//                                    position = phoneBltClass.getListFoundDeviceNames().indexOf(nameofBluetooth[0]);
//                                    device = phoneBltClass.getListFoundDevices().get(position);
//                                    str = " " + device;
//
//                                    txtview.setText(str);
//
//                                    phoneBltClass.creadBond(device);
//                                    txtview.setText("Bonded");
//                                    linlaHeaderProgress.setVisibility(View.GONE);
//                                }
//                            }
//                            adapterPairedDevices.notifyDataSetChanged();
//                            adapterPairedDeviceNames.notifyDataSetChanged();
//                            adapterFoundDeviceNames.notifyDataSetChanged();
//                            adapterFoundDevices.notifyDataSetChanged();
//                            txtview.setText(str);
//                            if(!phoneBltClass.getProgress())
//                                linlaHeaderProgress.setVisibility(View.GONE);
//
//
//                        }
                        break;
                    }
                }
            }
        });
    }



}//end smartCarpet

     * @param savedInstanceState
     */
