package com.example.myapplication;

import android.annotation.TargetApi;
import android.app.Activity;
import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;


import static android.bluetooth.BluetoothDevice.ACTION_BOND_STATE_CHANGED;
import static android.bluetooth.BluetoothDevice.ACTION_UUID;
import static android.bluetooth.BluetoothDevice.BOND_BONDED;
import static android.bluetooth.BluetoothDevice.BOND_BONDING;
import static android.bluetooth.BluetoothDevice.BOND_NONE;
import static android.bluetooth.BluetoothDevice.EXTRA_BOND_STATE;
import static android.bluetooth.BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE;
import static android.content.ContentValues.TAG;

@TargetApi(21)
public class PhoneBltClass {

    /**/
    public static int REQUEST_ENABLE_BT = 99;
    public static BluetoothAdapter mBluetoothAdapter = null;
    public static BluetoothManager mBluetoothManager = null;
    Context context;


    /*************************************************/

    public ArrayList<BluetoothDevice> getListFoundDevices() {
        return ListFoundDevices;
    }

    public void setListFoundDevices(ArrayList<BluetoothDevice> listFoundDevices) {
        ListFoundDevices = listFoundDevices;
        if (listener != null) listener.onChange("found");
    }

    ArrayList<BluetoothDevice> ListFoundDevices = new ArrayList<BluetoothDevice>();

    /***************************************/

    public ArrayList<String> getListFoundDeviceNames() {
        return ListFoundDeviceNames;
    }

    public void setListFoundDeviceNames(ArrayList<String> listFoundDeviceNames) {
        ListFoundDeviceNames = listFoundDeviceNames;
    }

    public ArrayList<String> ListFoundDeviceNames = new ArrayList<String>();

    /****************/

    public ArrayList<BluetoothDevice> getListPairedDevices() {
        return ListPairedDevices;
    }

    public void setListPairedDevices(ArrayList<BluetoothDevice> listPairedDevices) {
        ListPairedDevices = listPairedDevices;
        if (listener != null) listener.onChange("paired");
    }

    ArrayList<BluetoothDevice> ListPairedDevices = new ArrayList<BluetoothDevice>();

    public ArrayList<String> getListPairedDeviceNames() {
        return ListPairedDeviceNames;
    }

    public void setListPairedDeviceNames(ArrayList<String> listPairedDeviceNames) {
        ListPairedDeviceNames = listPairedDeviceNames;
    }

    ArrayList<String> ListPairedDeviceNames = new ArrayList<String>();

    public static BluetoothDevice getDevice() {
        return mydevice;
    }

    public void setDevice(BluetoothDevice mydevice) {
        this.mydevice = mydevice;
    }

    /********************/

    public static BluetoothDevice mydevice;

    /********************/


    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
        if (listener != null) listener.onChange("activity_connect");
    }

    public int state = -1;

    /**************/
    public int getBondState() {
        return bondState;
    }

    public void setBondState(int bond) {
        this.bondState = bond;
        if (listener != null) listener.onChange("bond");
    }

    public int bondState;

    /********************************/
    public Boolean getSearchDevices() {
        return searchDevices;
    }

    public void setSearchDevices(Boolean finishSearch) {
        this.searchDevices = finishSearch;
        if (listener != null) listener.onChange("searchDevices");
    }

    public Boolean searchDevices;

    /**************************/

    public int getStateBlAdapter() {
        return stateBlAdapter;
    }

    public void setStateBlAdapter(int stateBlAdapter) {
        this.stateBlAdapter = stateBlAdapter;
        if (listener != null) listener.onChange("stateBlAdapter");
    }

    public int stateBlAdapter;


    /**************************/

    public Boolean getProgress() {
        return progress;
    }

    public void setProgress(Boolean progress) {
        this.progress = progress;
        if (listener != null) listener.onChange("progress");
    }

    public Boolean progress = false;

    public Boolean getBluettoothIsReady() {
        return bluettoothIsReady;
    }

    public void setBluettoothIsReady(Boolean bluettoothIsReady) {
        this.bluettoothIsReady = bluettoothIsReady;
        if (listener != null) listener.onChange("bluettoothIsReady");
    }

    public Boolean bluettoothIsReady = false;

    /**************************/


    public void setListener(ChangeListener listener) {
        this.listener = listener;
    }

    public interface ChangeListener {
        void onChange(String s);

    }

    private ChangeListener listener;

    public ChangeListener getListener() {
        return listener;
    }


    public PhoneBltClass(Context context) {
        this.context = context;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            mBluetoothManager = (BluetoothManager) context.getSystemService(context.BLUETOOTH_SERVICE);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            mBluetoothAdapter = mBluetoothManager.getAdapter();
        } else {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }
    }


    public static boolean isBluetoothSupported() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
            return mBluetoothManager.getAdapter() != null ? true : false;
        } else {
            return BluetoothAdapter.getDefaultAdapter() != null ? true : false;
        }

    }

    /**
     * Whether current Android device Bluetooth is enabled.
     *
     * @return true：Bluetooth is enabled false：Bluetooth not enabled
     */
    public static boolean isBluetoothEnabled() {

        if (mBluetoothAdapter != null) {
            return mBluetoothAdapter.isEnabled();
        }

        return false;
    }


    public static boolean islowEnergySupported(Context context) {

        if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Force to turn on Bluetooth on Android device.
     *
     * @return true：force to turn on Bluetooth　success
     * false：force to turn on Bluetooth failure
     */
    public static boolean turnOnBluetooth() {

        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            return mBluetoothAdapter.enable();
        }
        return false;
    }

    public static boolean turnOffBluetooth() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (mBluetoothAdapter == null || mBluetoothAdapter.isEnabled()) {
            return mBluetoothAdapter.disable();
        }
        return false;
    }


    //    private int REQUEST_ENABLE_BT = 1;
    public void onActivityResult(int requestCode, int resultCode, Intent data, Button switch_bluetooth, TextView txt) {

        //   super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT) {
            switch (resultCode) {
                // When the user press OK button.
                case AppCompatActivity.RESULT_OK: {
                    // TODO
                    switch_bluetooth.setBackgroundResource(R.drawable.icon_blte_on);
                    if (islowEnergySupported(context)) {
                        txt.setText("Low Energy Device");
                    } else {
                        txt.setVisibility(View.GONE);
                    }
                    setBluettoothIsReady(true);
                    break;
                }
                // When the user press cancel button or back button.
                case AppCompatActivity.RESULT_CANCELED: {
                    // TODO
                    switch_bluetooth.setBackgroundResource(R.drawable.icon_blte_off);
                    txt.setVisibility(View.GONE);
                    break;
                }

                default:
                    break;
            }
        }
    }


    public Boolean checkBluetooth(Activity activity) {
        if (!isBluetoothEnabled()) {
            // Ensures Bluetooth is available on the device and it is enabled. If not,
            // displays a dialog requesting user permission to enable Bluetooth.
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            activity.startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            return false;
        } else {
            return true;
        }
    }


    // Create a BroadcastReceiver for ACTION_FOUND
    public final BroadcastReceiver mReceiverBluetooth = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            // When discovery finds a device

            final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, mBluetoothAdapter.ERROR);
            setState(state);
            if (action.equals(mBluetoothAdapter.ACTION_STATE_CHANGED)) {
                switch (state) {
                    case BluetoothAdapter.STATE_OFF:
                        setStateBlAdapter(BluetoothAdapter.STATE_OFF);
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        setStateBlAdapter(BluetoothAdapter.STATE_TURNING_OFF);
                        break;
                    case BluetoothAdapter.STATE_ON:
                        setStateBlAdapter(BluetoothAdapter.STATE_ON);
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        setStateBlAdapter(BluetoothAdapter.STATE_TURNING_ON);
                        break;

                }
            }
        }
    };


    public void enableBluetoothOnDevice() {
        if (mBluetoothAdapter == null) {
            displayToast("enableDisableBT: Does not have BT capabilities.");
        }
        if (!mBluetoothAdapter.isEnabled()) {
            displayToast("enableDisableBT: enabling BT.");

            Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            context.startActivity(enableBTIntent);

            IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            context.registerReceiver(mReceiverBluetooth, BTIntent);
        }
        if (mBluetoothAdapter.isEnabled()) {
            displayToast("enableDisableBT: disabling BT.");
            mBluetoothAdapter.disable();

            IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
            context.registerReceiver(mReceiverBluetooth, BTIntent);
        }
    }

    public final BroadcastReceiver mScantReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (action.equals(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED)) {
                int mode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, BluetoothAdapter.ERROR);
                switch (mode) {
                    //Device is in Discoverable Mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE:
                        displayToast("mScantReceiver: Discoverability Enabled.");
                        break;
                    //Device not in discoverable mode
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE:
                        displayToast("mScantReceiver: Discoverability Disabled. Able to receive connections.");
                        break;
                    case BluetoothAdapter.SCAN_MODE_NONE:
                        displayToast("mScantReceiver: Discoverability Disabled. Not able to receive connections.");
                        break;
                    case BluetoothAdapter.STATE_CONNECTING:
                        displayToast("mScantReceiver: Connecting....");
                        break;
                }
            }
        }
    };


    public final BroadcastReceiver mSearchBleutoothReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            //    setProgress(true);

            switch (action) {
                case BluetoothAdapter.ACTION_DISCOVERY_STARTED: {
                    setSearchDevices(false);
                    break;
                }
                case BluetoothDevice.ACTION_FOUND: {
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    // int rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI,Short.MIN_VALUE);
                    if (!ListFoundDevices.contains(device)) {
                        ListFoundDevices.add(device);
                        ListFoundDeviceNames.add(device.getName());
                    }
                    setListFoundDevices(ListFoundDevices);
                    setListFoundDeviceNames(ListFoundDeviceNames);
                    break;
                }
                case BluetoothAdapter.ACTION_DISCOVERY_FINISHED: {
                    setSearchDevices(true);
                    break;
                }

            }
        }
    };

    public final BroadcastReceiver bondStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            final BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

            // Ignore updates for other devices
            //  if (bluetoothGatt == null || !device.getAddress().equals(bluetoothGatt.getDevice().getAddress()))
            //      return;
            // Check if action is valid
            if (action == null) return;

            // Take action depending on new bond state
            if (action.equals(ACTION_BOND_STATE_CHANGED)) {

                final int bondState = intent.getIntExtra(EXTRA_BOND_STATE, BluetoothDevice.ERROR);
                final int previousBondState = intent.getIntExtra(BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE, -1);
                setBondState(bondState);
                switch (bondState) {
                    case BOND_BONDING:
                        // Bonding started
                        displayToast("Try bond...");
                        break;
                    case BOND_BONDED:
                        if (!getListPairedDevices().contains(device)) {
                            getListPairedDeviceNames().add(device.getName());
                            getListPairedDevices().add(device);
                            getListFoundDeviceNames().remove(device.getName());
                            getListFoundDevices().remove(device);
                        }
                        break;
                    case BOND_NONE:
                        break;

                }
            }
        }
    };


    public void PairedReceiver() {
        //   displayToast("Looking for paired devices.");
        // Query paired devices
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        final int size = pairedDevices.size();
        if (size > 0) {
            // Loop through paired devices
            for (BluetoothDevice device : pairedDevices) {
                // Create the device object and add it to the arrayList of devices
                if (!getListPairedDevices().contains(device)) {
                    getListPairedDevices().add(device);
                    getListPairedDeviceNames().add(device.getName());
                }
                setListPairedDevices(getListPairedDevices());
                setListFoundDevices(getListFoundDevices());
            }

        }
    }

    public ArrayList<BluetoothDevice> AlreadyPaired() {
        //   displayToast("Looking for paired devices.");
        // Query paired devices
        ArrayList<BluetoothDevice> pairedDevice = new ArrayList<BluetoothDevice>();
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        final int size = pairedDevices.size();
        if (size > 0) {
            // Loop through paired devices
            for (BluetoothDevice device : pairedDevices) {
                // Create the device object and add it to the arrayList of devices
                if (!pairedDevice.contains(device)) {
                    pairedDevice.add(device);
                }
            }
        }
        return pairedDevice;
    }


    public void displayToast(String str) {
        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
    }


    public void creadBond(BluetoothDevice device) {
        //NOTE: Requires API 17+? I think this is JellyBean
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN_MR2) {
            displayToast("Trying to pair with " + device.getName());
            device.createBond();
        }
        IntentFilter filter = new IntentFilter(EXTRA_BOND_STATE);
        filter.addAction(ACTION_BOND_STATE_CHANGED);
        filter.addAction(EXTRA_PREVIOUS_BOND_STATE);
        context.registerReceiver(bondStateReceiver, filter);
    }


    public Boolean removeBond(BluetoothDevice device) {

        Boolean result = false, bond = false;
        try {
            Method method = device.getClass().getMethod("removeBond", (Class[]) null);
            result = (boolean) method.invoke(device, (Object[]) null);
            if (result) {
                //   displayToast("Successfully removed bond");
                bond = true;
            } else {
                bond = false;
            }
        } catch (Exception e) {
            bond = false;
            displayToast("ERROR: could not remove bond");
            e.printStackTrace();
        }
        return bond;
    }


    private void unpairDevice(BluetoothDevice device) {
        try {
            Method method = device.getClass().getMethod("removeBond", (Class[]) null);
            method.invoke(device, (Object[]) null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    BluetoothProfile.ServiceListener mProfileListener = new BluetoothProfile.ServiceListener() {
        public void onServiceConnected(int profile, BluetoothProfile proxy) {
            if (profile == BluetoothProfile.A2DP) {
                boolean deviceConnected = false;
                BluetoothA2dp btA2dp = (BluetoothA2dp) proxy;
                List<BluetoothDevice> a2dpConnectedDevices = btA2dp.getConnectedDevices();
                if (a2dpConnectedDevices.size() != 0) {
                    for (BluetoothDevice device : a2dpConnectedDevices) {
                        if (device.getName().contains("DEVICE_NAME")) {
                            deviceConnected = true;
                            setState(1);
                        }
                    }
                }
                if (!deviceConnected) {
                    setState(0);
                }
                mBluetoothAdapter.closeProfileProxy(BluetoothProfile.A2DP, btA2dp);
            }
        }

        public void onServiceDisconnected(int profile) {
            // TODO
        }
    };
    private BluetoothSocket mmSocket =null,  btSocket = null;
  //private final UUID MY_UUID = UUID.fromString("ff355054-2623-11ea-978f-2e728ce88125");
    private final UUID MY_UUID = UUID.fromString("00000000-0000-1000-8000-00805f9b34fb");
    private OutputStream outStream = null;
    private DataOutputStream os;
    private DataInputStream is;


//    BroadcastReceiver discoveryResult = new BroadcastReceiver() {
//        public void onReceive(Context context, Intent intent) {
//            try {
//
//                btSocket = getDevice().createRfcommSocketToServiceRecord(MY_UUID);
//                Method m = getDevice().getClass().getMethod("createRfcommSocket", new Class[]{int.class});
//                btSocket = (BluetoothSocket) m.invoke(getDevice(), 1);
//            } catch (Exception e) {
//                e.printStackTrace();
//                displayToast("" + e.getMessage());
//            }
//
//            mmSocket = btSocket;
//
//            try {
//                mmSocket.activity_connect();
//                displayToast("Connected to BLE");
//
//            } catch (IOException connectException) {
//                try {
//                    mmSocket.close();
//                } catch (IOException closeException) {
//                    displayToast("Could not close the client socket " + closeException);
//                }
//                return;
//            }
//            try {
//                os = new DataOutputStream(mmSocket.getOutputStream());
//                is = new DataInputStream(mmSocket.getInputStream());
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//
//        }
//    };
//
//    public void connectDevice(BluetoothDevice device) {
//
//        context.registerReceiver(discoveryResult, new IntentFilter());
//
//        new clientSock().start();
//
//    }
//
//    public class clientSock extends Thread {
//        public void run() {
//
//            try {
//                os.writeBytes("anything you want"); // anything you want
//                os.flush();
//            } catch (Exception e1) {
//                e1.printStackTrace();
//                return;
//            }
//        }
//    }

    private BluetoothGatt bluetoothGatt=null;


//
//    private BluetoothAdapter bluetoothAdapter;
//    private boolean mScanning;
//    private Handler handler;
//
//    // Stops scanning after 10 seconds.
//    private static final long SCAN_PERIOD = 10000;
//
//    private void scanLeDevice(final boolean enable) {
//        if (enable) {
//            // Stops scanning after a pre-defined scan period.
//            handler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    mScanning = false;
//                    bluetoothAdapter.stopLeScan(leScanCallback);
//                }
//            }, SCAN_PERIOD);
//
//            mScanning = true;
//            bluetoothAdapter.startLeScan(leScanCallback);
//        } else {
//            mScanning = false;
//            bluetoothAdapter.stopLeScan(leScanCallback);
//        }
//
//    }
//
//    private LeDeviceListAdapter leDeviceListAdapter;
//    // Device scan callback.
//    private BluetoothAdapter.LeScanCallback leScanCallback =
//            new BluetoothAdapter.LeScanCallback() {
//                @Override
//                public void onLeScan(final BluetoothDevice device, int rssi,
//                                     byte[] scanRecord) {
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            leDeviceListAdapter.addDevice(device);
//                            leDeviceListAdapter.notifyDataSetChanged();
//                        }
//                    });
//                }
//            };

    public void connectToDevice(BluetoothDevice device) {
        bluetoothGatt=null;
        device.connectGatt(context, false, gattCallback);
        if (bluetoothGatt == null) {
            bluetoothGatt = device.connectGatt(context, false, gattCallback);


            //   scanLeDevice(false);// will stop after first device detection
            mBluetoothAdapter.cancelDiscovery();
        displayToast(bluetoothGatt+"");
        }

    }


    private int connectionState = STATE_DISCONNECTED;

    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;

    public final static String ACTION_GATT_CONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "com.example.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "com.example.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =
            "com.example.bluetooth.le.EXTRA_DATA";


    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
                @Override
                public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                    String intentAction;
                    displayToast("Status: " + status);
                    switch (newState) {
                        case BluetoothProfile.STATE_CONNECTED:
                            intentAction = ACTION_GATT_CONNECTED;
                            connectionState = STATE_CONNECTED;
                            displayToast("STATE_CONNECTED");
                            gatt.discoverServices();
                            broadcastUpdate(intentAction);

                            break;
                        case BluetoothProfile.STATE_DISCONNECTED:
                            intentAction = ACTION_GATT_DISCONNECTED;
                            connectionState = STATE_DISCONNECTED;
                            displayToast("STATE_DISCONNECTED");
                            broadcastUpdate(intentAction);
                            break;
                        default:
                            displayToast("STATE_OTHER");
                    }
                }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
            } else {
                displayToast( "onServicesDiscovered received: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic
                                                 characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            }

        }
    };


    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        context.sendBroadcast(intent);
    }

    private void broadcastUpdate(final String action,
                                 final BluetoothGattCharacteristic characteristic) {
        final Intent intent = new Intent(action);

        // This is special handling for the Heart Rate Measurement profile. Data
        // parsing is carried out as per profile specifications.
        if (MY_UUID.equals(characteristic.getUuid())) {
            int flag = characteristic.getProperties();
            int format = -1;
            if ((flag & 0x01) != 0) {
                format = BluetoothGattCharacteristic.FORMAT_UINT16;
                displayToast( "Heart rate format UINT16.");
            } else {
                format = BluetoothGattCharacteristic.FORMAT_UINT8;
                displayToast("Heart rate format UINT8.");
            }
            final int heartRate = characteristic.getIntValue(format, 1);
            Log.d(TAG, String.format("Received heart rate: %d", heartRate));
            intent.putExtra(EXTRA_DATA, String.valueOf(heartRate));
        } else {
            // For all other profiles, writes the data formatted in HEX.
            final byte[] data = characteristic.getValue();
            if (data != null && data.length > 0) {
                final StringBuilder stringBuilder = new StringBuilder(data.length);
                for(byte byteChar : data)
                    stringBuilder.append(String.format("%02X ", byteChar));
                intent.putExtra(EXTRA_DATA, new String(data) + "\n" +
                        stringBuilder.toString());
            }
        }
        context.sendBroadcast(intent);
    }




}


