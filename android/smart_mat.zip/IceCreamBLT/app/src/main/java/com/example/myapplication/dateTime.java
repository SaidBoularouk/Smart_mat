package com.example.myapplication;

import android.os.SystemClock;
import android.widget.Chronometer;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class dateTime {

    public Chronometer getSimpleChronometer() {
        return simpleChronometer;
    }

    public void setSimpleChronometer(Chronometer simpleChronometer) {
        this.simpleChronometer = simpleChronometer;
    }

    public  Chronometer simpleChronometer;
    public String getTotalDuration() {
        return totalDuration;
    }

    public void setTotalDuration(String totalDuration) {
        this.totalDuration = totalDuration;
    }

    String totalDuration="";

    public void setDate (TextView view){
        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");//formating according to my need
        String date = formatter.format(today);
        view.setText(date);
    }

    public void setTime (TextView view){

        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm:ss");//formating according to my need
        String date = formatter.format(today);
        view.setText(date);
    }


    public String date(){
        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");//formating according to my need
        return formatter.format(today);
    }

    public String  time(){
        Date today = Calendar.getInstance().getTime();//getting date
        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm:ss");//formating according to my need
        return formatter.format(today);
    }

    public void startChrono(final TextView txt){
        simpleChronometer.setBase(SystemClock.elapsedRealtime());
        simpleChronometer.stop();
        simpleChronometer.start();
        simpleChronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                long systemCurrTime = SystemClock.elapsedRealtime();
                long chronometerBaseTime = chronometer.getBase();
                long time = systemCurrTime - chronometerBaseTime;
                if(time > 10000)
                {
                    int h   = (int)(time /3600000);
                    int m = (int)(time - h*3600000)/60000;
                    int s= (int)(time - h*3600000- m*60000)/1000 ;
                    totalDuration = (h < 10 ? "0"+h: h)+":"+(m < 10 ? "0"+m: m)+":"+ (s < 10 ? "0"+s: s);
                    txt.setText(totalDuration);
                }
            }
        });

    }


    public void stopChrono(){
        simpleChronometer.stop();
    }


}
