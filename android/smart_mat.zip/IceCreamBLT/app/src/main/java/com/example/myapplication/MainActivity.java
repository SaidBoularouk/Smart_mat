package com.example.myapplication;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.os.SystemClock;
import android.view.View;

import android.content.IntentFilter;
import android.bluetooth.BluetoothAdapter;
import android.widget.ProgressBar;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements Serializable {

    private PhoneBltClass myBluetoothClass;
    private ProgressBar progressBar;
    private Handler handler = new Handler();
    private TextView txtPrgess, txtLowEnery;
    private Button enableBt, startConnect, bt,bt2;
    private Context context;
    private Thread thread[] = new Thread[2];
    private BluetoothDevice device;
    private int v=0;
    int wait1 = 30, wait2 = 30;
    BluetoothAdapter mBluetoothAdapter;
  //  private  bluetooth _bluetooth;

    private  esp32class connect_Device;

    private ArrayList<BluetoothDevice> ListFoundDevices =  new ArrayList<BluetoothDevice>(),
            ListPairedDevices =  new ArrayList<BluetoothDevice>();
    private ArrayList< String > ListFoundDeviceNames =  new ArrayList<String>(),
            ListPairedDeviceNames =  new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        handler = new Handler();
        context = this.getApplicationContext();

        myBluetoothClass = null;
        myBluetoothClass = new PhoneBltClass(this);
        connect_Device = new esp32class(this, handler);


       if (!myBluetoothClass.isBluetoothSupported()) {
            setContentView(R.layout.sorry);
            return;
        }
        setContentView(R.layout.activity_connect);
        enableBt = (Button) findViewById(R.id.enableBt);
        startConnect = (Button) findViewById(R.id.startConnection) ;
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        txtPrgess = (TextView) findViewById(R.id.progressText);
        txtLowEnery = (TextView) findViewById(R.id.lowEnergy);
        progressBar.setVisibility(View.GONE);
        txtLowEnery.setVisibility(View.GONE);

        bt = (Button) findViewById(R.id.button);
        bt2 =(Button) findViewById(R.id.button2);


        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(myBluetoothClass.mReceiverBluetooth, filter);


        bt2.setOnClickListener(new View.OnClickListener() {
                                   @Override
                                   public void onClick(View v) {

                                      connect_Device.scanLeDevice(true);
                                   }
                               }
        );

        if (myBluetoothClass.isBluetoothEnabled()) {
            wait1 = 30;
        }else{
            wait1 = 30;

        }

        if (alreadyPaired(deviceName)) {
            wait2 = 30;
        }else{
            wait2 = 30;
        }
        startConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /**/
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(0);
                txtPrgess.setVisibility(View.VISIBLE);
             //   new Thread(new Task()).start();

                thread[0] = new Thread(runSearch);
                thread[0].start();

            }
            });


        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this, Esp32Activity.class);
                startActivity(intent);
            }

        });

        ListnerMybltClass();
    }

private void showBlt() {
    progressBar.setVisibility(View.VISIBLE);
    progressBar.setProgress(0);

    if (myBluetoothClass.isBluetoothEnabled()) {
        txtPrgess.setText("Bluetooth ok");
        enableBt.setBackgroundResource(R.drawable.icon_blte_on);
        if (myBluetoothClass.islowEnergySupported(context)) {
            txtLowEnery.setText("Low Energy Supported");
        } else {   txtLowEnery.setVisibility(View.GONE);  }
        thread[1] = new Thread(runConnect);
        thread[1].start();
    }
    else {

        enableBt.setBackgroundResource(R.drawable.icon_blte_off);
        txtPrgess.setText("Click to enable Bluetooth");

        Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivity(enableBTIntent);

        IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(myBluetoothClass.mReceiverBluetooth, BTIntent);

        enableBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
             startActivity(enableBTIntent);

             IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
             registerReceiver(myBluetoothClass.mReceiverBluetooth, BTIntent);

            }
        });

  }
   /***Start search for esp32 */

    txtPrgess.setText(myBluetoothClass.isBluetoothEnabled() +"");
    startConnect.setEnabled(true);
    // progressBar.setVisibility(View.GONE);
    //txtPrgess.setVisibility(View.GONE);

}

private String deviceName = "SmartCarpet";

private Boolean alreadyPaired(String nameOfBle) {
    Boolean b = false;
    ListPairedDevices = myBluetoothClass.AlreadyPaired();
    for (BluetoothDevice bD : ListPairedDevices) {
        ListPairedDeviceNames.add(bD.getName());
    }

    if (!ListPairedDeviceNames.isEmpty() && ListPairedDeviceNames.contains(nameOfBle)) {
        b=true;
    } else {
        b=false;
    }
    return b;
}
private void startConnectToPic(String nameOfBle){
    progressBar.setProgress(0);
    txtPrgess.setText("Starting connection..");

    if (alreadyPaired(nameOfBle)) {
        txtPrgess.setText("Success");
        int position = ListPairedDeviceNames.indexOf(nameOfBle);
        device = ListPairedDevices.get(position);
        myBluetoothClass.setDevice(device);
        myBluetoothClass.setBluettoothIsReady(true);
    } else {
        ListFoundDeviceNames = new ArrayList<String>();
        ListFoundDevices = new ArrayList<BluetoothDevice>();
            txtPrgess.setText("Search devices..");
        if (myBluetoothClass.mBluetoothAdapter.isDiscovering()) {
            myBluetoothClass.displayToast("Canceling discovery.");
            myBluetoothClass.mBluetoothAdapter.cancelDiscovery();
        } else {
            myBluetoothClass.mBluetoothAdapter.startDiscovery();
            txtPrgess.setText("wait search..");
        }
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(myBluetoothClass.mSearchBleutoothReceiver, filter);
     }

}

private  boolean succed = false;

public Runnable runConnect = new Runnable() {
        @Override
        public void run() {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(0);
            for (int i = 0; i <= 100; i++) {
                final int value = i;
                try {
                    Thread.sleep(wait2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setProgress(value);
                        if(value == 100) {
                            startConnectToPic(deviceName);
                        }
                    }
                });
            }
        }
};

/**/
public Runnable runSearch = new Runnable() {
      @Override
      public void run() {
          for (int i = 0; i <= 100; i++) {
              final int value = i;
              try {
                  Thread.sleep(wait1);
              } catch (InterruptedException e) {
                  e.printStackTrace();
              }
              handler.post(new Runnable() {
                  @Override
                  public void run() {
                      progressBar.setProgress(value);
                      if(value==100) {
                          showBlt();
                      }
                  }
              });
          }
      }
  };


    protected void askDevice(String str){
        connect_Device.connect(device);
        connect_Device.readDataNotif();
        connect_Device.writeDataNotif(str);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        myBluetoothClass.onActivityResult(requestCode, resultCode, data, enableBt, txtLowEnery);

    }


    @Override
    protected void onStart() {
        super.onStart();
    }

    private void ListnerMybltClass(){

        connect_Device.setListener(new esp32class.ChangeListener(){
            @Override
            public void onChange (String s){
                int i = 0;
                switch (s) {
                    case"connectionStatusChange":
                        Toast.makeText(MainActivity.this,  connect_Device.getconnectionState()+"", Toast.LENGTH_SHORT).show();
                        if(connect_Device.getconnectionState()==2){
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(MainActivity.this,  "BLE is connected" + deviceName, Toast.LENGTH_SHORT).show();
                                    connect_Device.writeDataNotif("salam");


                                }
                            });


                        }
                        if(connect_Device.getconnectionState()==0){
                            SystemClock.sleep(1000);
                            Toast.makeText(MainActivity.this,  "BLE not connected", Toast.LENGTH_SHORT).show();
                            connect_Device.connect(myBluetoothClass.getDevice());
                        }
                        if(connect_Device.getconnectionState()==1){
                            Toast.makeText(MainActivity.this,  "BLE connecting", Toast.LENGTH_SHORT).show();
                           SystemClock.sleep(1000);
                            connect_Device.connect(myBluetoothClass.getDevice());

                        }
                        break;
                    case "msgChange": {
                        String msg = connect_Device.getmsg();
                        if (msg.charAt(0) == '#' && msg.charAt(msg.length() - 2) == '$') {
                            String _msg = msg.substring(1, msg.length() - 2);
                            if (_msg.contains("salam")) {
                                runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Intent intent = new Intent(MainActivity.this, Esp32Activity.class);
                                    startActivity(intent);
                                    }
                            });
                        }
                            if (_msg.contains("none")) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {  }
                             });
                        }
                    }

                    break;
                }
            }
            }
        });

        myBluetoothClass.setListener(new PhoneBltClass.ChangeListener() {
            @Override
            public void onChange(String s) {

                switch (s) {
                    case "stateBlAdapter": {
                        switch (myBluetoothClass.getStateBlAdapter()) {
                            case BluetoothAdapter.STATE_OFF: {
                                enableBt.setBackgroundResource(R.drawable.icon_blte_off);
                                txtPrgess.setText("Click to enable Bluetooth");
                                txtLowEnery.setVisibility(View.GONE);
                                break;
                            }
                            case BluetoothAdapter.STATE_ON: {
                                enableBt.setBackgroundResource(R.drawable.icon_blte_on);
                                txtPrgess.setText("Bluetooth ok");
//                                startConnect.setEnabled(false);
                                if(myBluetoothClass.islowEnergySupported(context)){
                                    txtLowEnery.setVisibility(View.VISIBLE);
                                    txtLowEnery.setText("Low Energy Device");
                                }else{
                                    txtLowEnery.setVisibility(View.GONE);
                                }
                                thread[1] = new Thread(runConnect);
                                thread[1].start();
                            break;
                            }
                        }
                    break;
                    }
                    case "paired":{
                        ListPairedDeviceNames = myBluetoothClass.getListPairedDeviceNames();
                        ListPairedDevices = myBluetoothClass.getListPairedDevices();
                    break;
                    }
                    case "bond": {
                        txtPrgess.setText("Try bond..");
                        switch (myBluetoothClass.getBondState()) {
                            case BluetoothDevice.BOND_BONDED:
                                txtPrgess.setText("Bond success");
                                txtPrgess.setText("Try to activity_connect");
                                myBluetoothClass.setBluettoothIsReady(true);
                                // Bonding started
                            break;
                            case BluetoothDevice.BOND_NONE:
                                txtPrgess.setText("Unsuccess bond");
                                myBluetoothClass.setBluettoothIsReady(false);
                            break;
                        }
                    break;
                    }

                    case "found":
                        ListFoundDeviceNames = myBluetoothClass.getListFoundDeviceNames();
                        ListFoundDevices = myBluetoothClass.getListFoundDevices();
                        txtPrgess.setText(""+ListFoundDevices.size());
                        break;
                    case "searchDevices":{
                        txtPrgess.setText( deviceName+","+ ListFoundDeviceNames.size());
                        if(myBluetoothClass.getSearchDevices()) {
                            if (ListFoundDeviceNames.contains(deviceName)) {
                                int position = ListFoundDeviceNames.indexOf(deviceName);
                                device = ListFoundDevices.get(position);
                                myBluetoothClass.setDevice(device);
                                myBluetoothClass.creadBond(myBluetoothClass.getDevice());
                            }else {
                                txtPrgess.setText("Can't find device");
                            }
                            } else {
                                v = v + 10;
                                progressBar.setProgress(v);
                            }

                    break;
                    }

                    case "bluettoothIsReady":{
                        if(myBluetoothClass.getBluettoothIsReady()) {
                            connect_Device.setDevice(myBluetoothClass.getDevice());
                            connect_Device.connect(myBluetoothClass.getDevice());
                            txtPrgess.setText("Connecting .." + myBluetoothClass.getDevice() + deviceName);
                        }else{
                           txtPrgess.setText("Can't connect, sorry");
                        }
                    break;
                    }



                }

            }



        });
    }

    @Override
    protected void onDestroy() {
        myBluetoothClass.displayToast("onDestroy: called.");
        super.onDestroy();
        try {
            //Register or UnRegister your broadcast receiver here
            unregisterReceiver(myBluetoothClass.mReceiverBluetooth);
            unregisterReceiver(myBluetoothClass.mScantReceiver);
            unregisterReceiver(myBluetoothClass.mSearchBleutoothReceiver);
            unregisterReceiver(myBluetoothClass.bondStateReceiver);
            //unregisterReceiver(mPairedChangeReceiver);
            myBluetoothClass.mBluetoothAdapter.cancelDiscovery();
        } catch(IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

}//end MainActivity
